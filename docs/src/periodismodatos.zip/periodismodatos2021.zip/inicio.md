<h1 id="presentación-página-web">¡Te presento mi página web!</h1>

<p>En esta página se han recopilado las diferentes prácticas realizadas en Periodismo de Datos, durante el primer cuatrimestre del curso 2021-2022.</p>

<p>Como se puede observar, cada apartado contiene distintas infografías (de elaboración propia y ajena) junto a un comentario personal de las mismas. Además, se incluye una metodología con el proceso.</p>
